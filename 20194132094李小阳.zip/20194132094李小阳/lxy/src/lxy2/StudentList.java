package lxy2;


import java.io.BufferedWriter;
import java.io.FileWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.TreeSet;



public  class StudentList  {
private TreeSet<Student> ts=new TreeSet<Student>();

public void add(){
	Student s1=new Student(4132094,"��С��");
	Student s2=new Student(4132095,"������");
	Student s3=new Student(4132096,"������");
	ts.add(s1);
	ts.add(s2);
	ts.add(s3);
}

public  void show(){
	
	System.out.println(ts.toString());
}
public void search(int id) throws Exception{
	
boolean floge=true;
	java.util.Iterator<Student> it=ts.iterator();
	while(it.hasNext()) {
		Student student=it.next();
		if(student.getId()==id) {
			
			FileWriter fileWriter = new FileWriter("D:\\20194132094.txt");
			BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
			bufferedWriter.write(student.toString());
			//�ر���Դ
			bufferedWriter.close();
			
			it.remove();
			floge=false;
		}
	}
	if(floge){
		System.out.println("���޴�ѧ��");
	}
	}
	
	

public void save(){
	try {
		Class.forName("com.mysql.jdbc.Driver");
		
		//2.��ȡ���ݿ����Ӷ���
Connection conn= DriverManager.getConnection("jdbc:mysql://localhost:3306/lxy", "root", "root");

 for(Student iteam:ts){
	 PreparedStatement pst=conn.prepareStatement("INSERT into 20194132094_info (id,name)VALUES(?,?)");
	 pst.setObject(1,iteam.getId());
	 pst.setObject(2,iteam.getName());
	 pst.executeUpdate();
	
 }


 PreparedStatement pst=conn.prepareStatement("SELECT * FROM 20194132094_info");
  ResultSet r= pst.executeQuery();
while(r.next()){
	System.out.println(r.getInt("id")+r.getString("name"));
}

pst.close();
//6.�ر����ͷ���Դ
conn.close();//���Ӷ���ر�


	} catch (Exception e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
	
	
	
	
}


}


