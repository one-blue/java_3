package lxy2;

public class lxy {
public static void main(String[] args) throws Exception {
	StudentList sl=new StudentList();
	sl.add();
	sl.show();
	sl.search(4132099);
	sl.show();
	sl.save();
	
			
}
}
