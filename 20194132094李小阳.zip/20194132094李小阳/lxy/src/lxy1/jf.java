package lxy1;
import java.awt.Panel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;
public class jf {
	
	 static JLabel jl=new JLabel();
		
public static void main(String[] args) {
	SwingUtilities.invokeLater(() -> meth());
	
	
	}

	private static void meth(  ) {
		JFrame jf=new JFrame("�ַ��Ծ�");
		//���ÿ��ߣ�����
		jf.setBounds(497, 242, 426, 300);
		
		
		
	
		Panel p1=new Panel();
		JButton jb=new JButton("�ַ��Ծ�");
	
		JTextArea jt=new JTextArea(5,5);
		
		jb.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				Test  ts=new  Test();
				new Thread(ts,"4132094").start();
				new Thread(ts,"��С��").start();
			}
	class Test implements Runnable{
		int jz=Integer.parseInt(jt.getText());
		@Override
		public void run() {
			while(true){
				if(jz<=0){
					break;
				}
				
					
					 jl.setText(Thread.currentThread().getName()+"��"+jz--+"�ݾ���");
				
				
				
				
			}
			
		}
	}
		});
		
		
		
		
		
		
		
		
		
	
		
		
p1.add(jl);
	
		p1.add(jt);
		p1.add(jb);
		jf.add(p1);
		//��ʾ����
	
		jf.setVisible(true);
		jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		
	}}
