/*
 Navicat Premium Data Transfer

 Source Server         : localhost_3306
 Source Server Type    : MySQL
 Source Server Version : 50540
 Source Host           : localhost:3306
 Source Schema         : lxy

 Target Server Type    : MySQL
 Target Server Version : 50540
 File Encoding         : 65001

 Date: 17/06/2020 20:06:11
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for 20194132094_info
-- ----------------------------
DROP TABLE IF EXISTS `20194132094_info`;
CREATE TABLE `20194132094_info`  (
  `id` int(255) NOT NULL,
  `name` varchar(11) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of 20194132094_info
-- ----------------------------
INSERT INTO `20194132094_info` VALUES (4132094, '李小阳');
INSERT INTO `20194132094_info` VALUES (4132095, '啦啦啦');
INSERT INTO `20194132094_info` VALUES (4132096, '略略略');

SET FOREIGN_KEY_CHECKS = 1;
